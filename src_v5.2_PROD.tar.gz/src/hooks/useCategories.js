import { useState, useCallback } from "react";
import { ALL_CATS } from "../constants";

/**
 * useCategories.js - Hook independiente para gestionar categorías del usuario
 *
 * Este hook encapsula toda la lógica de categorías.
 * En el futuro, aquí es donde se conectaría a la BD del usuario.
 *
 * Retorna:
 *   - categories: {pillarId: [cat1, cat2, ...]}
 *   - addCategory: (pillarId, categoryName) → agrega categoría
 *   - deleteCategory: (categoryName, pillarId) → elimina categoría
 *   - editCategory: (oldName, newName, oldPillarId, newPillarId) → edita categoría
 */

// 🆕 Función auxiliar para inicializar categorías desde ALL_CATS
function initializeCategoriesFromAllCats(allCats) {
  const categories = {};

  allCats.forEach((cat) => {
    const pillarId = cat.pillar;
    if (!categories[pillarId]) {
      categories[pillarId] = [];
    }
    categories[pillarId].push(cat.name);
  });

  return categories;
}

export function useCategories() {
  // 🆕 Estado de categorías - aquí es donde se conectaría a la BD del usuario
  const [categories, setCategories] = useState(() =>
    initializeCategoriesFromAllCats(ALL_CATS)
  );

  // 🆕 Agregar categoría
  const addCategory = useCallback((pillarId, categoryName) => {
    setCategories((prev) => ({
      ...prev,
      [pillarId]: [...(prev[pillarId] || []), categoryName],
    }));
  }, []);

  // 🆕 Eliminar categoría
  const deleteCategory = useCallback((categoryName, pillarId) => {
    setCategories((prev) => ({
      ...prev,
      [pillarId]: (prev[pillarId] || []).filter((cat) => cat !== categoryName),
    }));
  }, []);

  // 🆕 Editar categoría (cambiar nombre y/o pilar)
  const editCategory = useCallback((oldName, newName, oldPillarId, newPillarId) => {
    setCategories((prev) => {
      const updated = { ...prev };

      // Eliminar del pilar anterior
      if (oldPillarId) {
        updated[oldPillarId] = (updated[oldPillarId] || []).filter(
          (cat) => cat !== oldName
        );
      }

      // Agregar al nuevo pilar
      updated[newPillarId] = [...(updated[newPillarId] || []), newName];

      return updated;
    });
  }, []);

  return {
    categories,
    addCategory,
    deleteCategory,
    editCategory,
  };
}
