import { useState, useEffect } from "react";

/**
 * usePillarBudgets.js - Hook independiente para gestionar presupuestos de pilares
 *
 * Maneja presupuestos personalizados de pilares por mes/año.
 * Se guarda en localStorage para persistencia.
 *
 * Retorna:
 *   - customBudgets: {keyMesAño: {pillarId: presupuesto, ...}, ...}
 *   - setCustomBudgets: actualiza los presupuestos
 */

export function usePillarBudgets() {
  const [customBudgets, setCustomBudgets] = useState({});

  // 🔄 DEV: Cargar presupuestos desde localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem("orus_pillar_budgets");
      if (stored) {
        setCustomBudgets(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Error loading pillar budgets:", e);
    }
  }, []);

  // 🔄 DEV: Guardar presupuestos en localStorage cuando cambien
  useEffect(() => {
    localStorage.setItem("orus_pillar_budgets", JSON.stringify(customBudgets));
  }, [customBudgets]);

  return {
    customBudgets,
    setCustomBudgets
  };
}
