/**
 * ColorBar.jsx
 *
 * ESTADO 2: Barra de colores de pilares + saldo
 * Visualiza la distribución proporcional de gastos/saldo como una barra horizontal segmentada
 * Cada segmento es clickeable para filtrar por pilar
 *
 * Props:
 *   segments - Array de segmentos {id, color, pct}
 *   filteredPillar - ID del pilar actual filtrado (null si no hay filtro)
 *   setFilteredPillar - Callback para cambiar filtro
 *   setFilterType - Callback para limpiar filtro de tipo
 */
export default function ColorBar({
  segments,
  filteredPillar,
  setFilteredPillar,
  setFilterType,
}) {
  return (
    <div style={{ display: "flex", height: 7, borderRadius: 5, overflow: "hidden", gap: 2 }}>
      {segments.map((seg) => (
        <div
          key={seg.id}
          onClick={() => {
            // Filtros mutuamente excluyentes: limpiar filterType
            if (filteredPillar !== seg.id) {
              setFilterType(null);
            }
            setFilteredPillar(filteredPillar === seg.id ? null : seg.id);
          }}
          style={{
            flex: seg.pct,
            background: seg.color,
            borderRadius: 3,
            cursor: "pointer",
            opacity: filteredPillar && filteredPillar !== seg.id ? 0.28 : 1,
            transition: "opacity 0.25s",
          }}
        />
      ))}
    </div>
  );
}
