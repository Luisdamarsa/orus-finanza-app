import { useState } from "react";
import { PILLARS } from "../constants";

/**
 * CategoriesPage.jsx
 *
 * Página de administración de categorías
 * Muestra todas las categorías agrupadas por pilar
 * Permite agregar nuevas categorías
 *
 * Props:
 *   isDark - Tema oscuro
 *   onBack - Callback para volver atrás
 *   onAddCategory - Callback para abrir AddCategoryPage (nueva)
 *   onEditCategory - Callback para editar categoría (categoryName, pillarId)
 *   categories - {pillarId: [cat1, cat2, ...]}
 */
export default function CategoriesPage({
  isDark,
  onBack,
  onAddCategory,
  onEditCategory,
  categories = {},
}) {
  const t = isDark
    ? { bg: "#000000", card: "#1E1E2E", border: "#2D2D3A", text: "#F0EEFF", sub: "#7B7A99" }
    : { bg: "#F8F7FF", card: "#FFFFFF", border: "#E5E3F5", text: "#1A1830", sub: "#9896B0" };

  return (
    <div style={{ width: "100%", height: "100%", background: t.bg, position: "relative" }}>
      {/* Header fijo (top: 52, height: 52) */}
      <div style={{
        position: "absolute", top: 52, left: 0, right: 0, height: 52,
        background: t.bg, padding: "8px 22px", boxSizing: "border-box",
        borderBottom: `1px solid ${t.border}`, zIndex: 30,
        display: "flex", alignItems: "center", justifyContent: "space-between"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            onClick={onBack}
            style={{
              width: 30,
              height: 30,
              borderRadius: 9,
              border: "none",
              background: isDark ? "#1E1E2E" : "#EEE9FF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke={isDark ? "#C4C2E0" : "#6B7280"}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
          <span style={{ fontSize: 12, color: t.sub, fontWeight: 500 }}>Atrás</span>
        </div>
      </div>

      {/* Sección de Título (top: 104, height: 60) */}
      <div style={{
        position: "absolute",
        top: 104,
        left: 0,
        right: 0,
        height: 60,
        background: t.bg,
        padding: "0 22px",
        boxSizing: "border-box",
        zIndex: 25,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}>
        <div style={{
          fontSize: 20,
          fontWeight: 700,
          color: t.text,
          flex: 1,
          textAlign: "center",
        }}>
          🏷️ Categorías
        </div>
      </div>

      {/* Contenido scrolleable (top: 164) */}
      <div style={{
        position: "absolute", top: 164, left: 0, right: 0, bottom: 0,
        overflowY: "auto", overflowX: "hidden", scrollbarWidth: "none",
        padding: "20px 22px 20px 22px", boxSizing: "border-box"
      }}>
        <style>{`::-webkit-scrollbar { display: none; }`}</style>
        {/* Pilares y sus categorías */}
        {PILLARS.map((pillar) => {
          const pillarCategories = categories[pillar.id] || [];

          return (
            <div key={pillar.id} style={{ marginBottom: 16 }}>
              {/* Título del Pilar - Con tag/badge (icono + nombre dentro) */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 12,
                  padding: "0 12px",
                }}
              >
                <div
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                    padding: "8px 14px",
                    borderRadius: 8,
                    background: pillar.color + "22",
                    border: `1px solid ${pillar.color}44`,
                    marginLeft: "-12px",
                  }}
                >
                  <span style={{ fontSize: 20.7 }}>{pillar.icon}</span>
                  <span style={{ fontSize: 16.1, fontWeight: 700, color: pillar.color, textTransform: "uppercase", letterSpacing: 0.5 }}>
                    {pillar.label}
                  </span>
                </div>
              </div>

              {/* Categorías del Pilar */}
              <div
                style={{
                  background: "transparent",
                  border: `1px solid ${t.border}`,
                  borderRadius: 12,
                  padding: 0,
                  marginBottom: 8,
                  overflow: "hidden",
                }}
              >
                {pillarCategories.length > 0 ? (
                  pillarCategories.map((cat, idx) => (
                    <button
                      key={idx}
                      onClick={() => onEditCategory(cat, pillar.id)}
                      style={{
                        width: "100%",
                        padding: "10px 16px",
                        borderBottom: idx < pillarCategories.length - 1 ? `1px solid ${t.border}` : "none",
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        fontSize: 13,
                        color: t.text,
                        background: "transparent",
                        border: "none",
                        cursor: "pointer",
                        textAlign: "left",
                        transition: "background 0.2s",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.background = isDark ? "#252538" : "#F0EFF8";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.background = "transparent";
                      }}
                    >
                      <span>{cat}</span>
                    </button>
                  ))
                ) : (
                  <div
                    style={{
                      padding: "12px 16px",
                      fontSize: 13,
                      color: t.sub,
                      fontStyle: "italic",
                    }}
                  >
                    Sin categorías
                  </div>
                )}
              </div>
            </div>
          );
        })}

      </div>

      {/* Botón Flotante Añadir Categoría */}
      <div style={{ position: "absolute", bottom: 24, right: 22 }}>
        <button
          onClick={onAddCategory}
          style={{
            padding: "12px 18px",
            borderRadius: 20,
            border: "none",
            background: "linear-gradient(135deg, #9B6DFF, #4F8EF7)",
            cursor: "pointer",
            boxShadow: "0 6px 24px rgba(155,109,255,0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            opacity: 1,
            transition: "all 0.2s",
            fontSize: 14,
            color: "white",
            fontWeight: 700,
            whiteSpace: "nowrap",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "scale(1.05)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "scale(1)";
          }}
        >
          <span style={{ fontSize: 18 }}>+</span>
          <span>Añadir categoría</span>
        </button>
      </div>

    </div>
  );
}
