import { useState } from "react";
import { PILLARS } from "../constants";

/**
 * AddCategoryPage.jsx
 *
 * Página modal para agregar una nueva categoría
 * Permite seleccionar nombre y pilar
 * Botón Guardar deshabilitado si el nombre < 2 caracteres
 *
 * Props:
 *   isDark - Tema oscuro
 *   onBack - Callback para volver atrás
 *   onSave - Callback(pillarId, categoryName) para guardar
 */
export default function AddCategoryPage({
  isDark,
  onBack,
  onSave,
}) {
  const [categoryName, setCategoryName] = useState("");
  const [selectedPillar, setSelectedPillar] = useState(PILLARS[0]?.id || null);

  const t = isDark
    ? { bg: "#000000", card: "#1E1E2E", border: "#2D2D3A", text: "#F0EEFF", sub: "#7B7A99", input: "#0D0D1A" }
    : { bg: "#F8F7FF", card: "#FFFFFF", border: "#E5E3F5", text: "#1A1830", sub: "#9896B0", input: "#F8F7FF" };

  const isValid = categoryName.trim().length >= 2;
  const selectedPillarData = PILLARS.find((p) => p.id === selectedPillar);

  const handleSave = () => {
    if (isValid && selectedPillar) {
      onSave(selectedPillar, categoryName.trim());
    }
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        background: t.bg,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 18px",
        overflow: "hidden",
      }}
    >
      {/* Modal Card */}
      <div
        style={{
          width: "100%",
          maxWidth: 340,
          background: t.card,
          borderRadius: 20,
          border: `1px solid ${t.border}`,
          padding: "24px",
          boxShadow: "0 24px 60px rgba(0,0,0,0.4)",
          animation: "popIn 0.22s cubic-bezier(.34,1.56,.64,1)",
        }}
      >
        <style>{`@keyframes popIn { from { transform:scale(0.92);opacity:0 } to { transform:scale(1);opacity:1 } }`}</style>

        {/* Header */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 24,
          }}
        >
          <div style={{ fontSize: 16, fontWeight: 800, color: t.text }}>Nueva Categoría</div>
          <button
            onClick={onBack}
            style={{
              width: 28,
              height: 28,
              borderRadius: "50%",
              background: isDark ? "#2D2D3A" : "#F0EFF8",
              border: "none",
              fontSize: 14,
              cursor: "pointer",
              color: t.sub,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            ✕
          </button>
        </div>

        {/* Nombre Input */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 10, fontWeight: 700, color: t.sub, letterSpacing: 0.5, display: "block", marginBottom: 8 }}>
            NOMBRE
          </label>
          <input
            type="text"
            value={categoryName}
            onChange={(e) => setCategoryName(e.target.value)}
            placeholder="Categoría"
            style={{
              width: "100%",
              padding: "12px 16px",
              borderRadius: 8,
              border: `1px solid ${t.border}`,
              background: isDark ? "#0D0D1A" : "#F8F7FF",
              color: t.text,
              fontSize: 13,
              boxSizing: "border-box",
              outline: "none",
              transition: "border-color 0.2s",
            }}
            onFocus={(e) => {
              e.target.style.borderColor = "#9B6DFF";
            }}
            onBlur={(e) => {
              e.target.style.borderColor = t.border;
            }}
          />
          {categoryName.length > 0 && categoryName.length < 2 && (
            <div style={{ fontSize: 10, color: "#EF4444", marginTop: 4 }}>
              Mínimo 2 caracteres ({categoryName.length}/2)
            </div>
          )}
        </div>

        {/* Pilar Select */}
        <div style={{ marginBottom: 24 }}>
          <label style={{ fontSize: 10, fontWeight: 700, color: t.sub, letterSpacing: 0.5, display: "block", marginBottom: 8 }}>
            PILAR
          </label>
          <select
            value={selectedPillar}
            onChange={(e) => setSelectedPillar(e.target.value)}
            style={{
              width: "100%",
              padding: "12px 16px",
              borderRadius: 8,
              border: `1px solid ${t.border}`,
              background: isDark ? "#0D0D1A" : "#F8F7FF",
              color: t.text,
              fontSize: 13,
              boxSizing: "border-box",
              outline: "none",
              cursor: "pointer",
              transition: "border-color 0.2s",
            }}
          >
            {PILLARS.map((pillar) => (
              <option key={pillar.id} value={pillar.id} style={{ background: isDark ? "#1E1E2E" : "#FFFFFF", color: t.text }}>
                {pillar.icon} {pillar.label}
              </option>
            ))}
          </select>
        </div>

        {/* Guardar Button */}
        <button
          onClick={handleSave}
          disabled={!isValid}
          style={{
            width: "100%",
            padding: "14px",
            borderRadius: 10,
            border: "none",
            background: isValid ? "#9B6DFF" : t.sub,
            color: "white",
            fontSize: 13,
            fontWeight: 700,
            cursor: isValid ? "pointer" : "not-allowed",
            opacity: isValid ? 1 : 0.5,
            transition: "all 0.2s",
          }}
          onMouseEnter={(e) => {
            if (isValid) {
              e.target.style.background = "#8A5FD9";
            }
          }}
          onMouseLeave={(e) => {
            if (isValid) {
              e.target.style.background = "#9B6DFF";
            }
          }}
        >
          Guardar
        </button>

        {/* Info */}
        <div style={{ fontSize: 11, color: t.sub, marginTop: 12, textAlign: "center", fontStyle: "italic" }}>
          Mínimo 2 caracteres para guardar
        </div>
      </div>
    </div>
  );
}
