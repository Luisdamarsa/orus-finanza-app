import { useState } from "react";
import { PILLARS } from "../constants";

/**
 * CategoriesPage.jsx
 *
 * Página de administración de categorías
 * Muestra todas las categorías agrupadas por pilar
 * Permite agregar nuevas categorías
 *
 * Props:
 *   isDark - Tema oscuro
 *   onBack - Callback para volver atrás
 *   onAddCategory - Callback para abrir AddCategoryPage
 *   categories - {pillarId: [cat1, cat2, ...]}
 */
export default function CategoriesPage({
  isDark,
  onBack,
  onAddCategory,
  categories = {},
}) {
  const t = isDark
    ? { bg: "#000000", card: "#1E1E2E", border: "#2D2D3A", text: "#F0EEFF", sub: "#7B7A99" }
    : { bg: "#F8F7FF", card: "#FFFFFF", border: "#E5E3F5", text: "#1A1830", sub: "#9896B0" };

  return (
    <div style={{ width: "100%", height: "100%", background: t.bg, position: "relative" }}>
      {/* Header fijo (top: 52, height: 52) */}
      <div style={{
        position: "absolute", top: 52, left: 0, right: 0, height: 52,
        background: t.bg, padding: "8px 22px", boxSizing: "border-box",
        borderBottom: `1px solid ${t.border}`, zIndex: 30,
        display: "flex", alignItems: "center", justifyContent: "space-between"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <button
            onClick={onBack}
            style={{
              width: 30,
              height: 30,
              borderRadius: 9,
              border: "none",
              background: isDark ? "#1E1E2E" : "#EEE9FF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke={isDark ? "#C4C2E0" : "#6B7280"}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6" />
            </svg>
          </button>
          <span style={{ fontSize: 12, color: t.sub, fontWeight: 500 }}>Atrás</span>
        </div>
      </div>

      {/* Sección de Título (top: 104, height: 60) */}
      <div style={{
        position: "absolute",
        top: 104,
        left: 0,
        right: 0,
        height: 60,
        background: t.bg,
        padding: "0 22px",
        boxSizing: "border-box",
        zIndex: 25,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}>
        <div style={{
          fontSize: 20,
          fontWeight: 700,
          color: t.text,
          flex: 1,
          textAlign: "center",
        }}>
          🏷️ Categorías
        </div>
      </div>

      {/* Contenido scrolleable (top: 164) */}
      <div style={{
        position: "absolute", top: 164, left: 0, right: 0, bottom: 0,
        overflowY: "auto", overflowX: "hidden", scrollbarWidth: "none",
        padding: "20px 22px 20px 22px", boxSizing: "border-box"
      }}>
        <style>{`::-webkit-scrollbar { display: none; }`}</style>
        {/* Pilares y sus categorías */}
        {PILLARS.map((pillar) => {
          const pillarCategories = categories[pillar.id] || [];

          return (
            <div key={pillar.id} style={{ marginBottom: 16 }}>
              {/* Título del Pilar */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 12,
                  padding: "0 12px",
                }}
              >
                <span style={{ fontSize: 18 }}>{pillar.icon}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: t.text }}>
                  {pillar.label}
                </span>
              </div>

              {/* Categorías del Pilar */}
              <div
                style={{
                  background: t.card,
                  border: `1px solid ${t.border}`,
                  borderRadius: 12,
                  padding: "12px 0",
                  marginBottom: 8,
                  overflow: "hidden",
                }}
              >
                {pillarCategories.length > 0 ? (
                  pillarCategories.map((cat, idx) => (
                    <div
                      key={idx}
                      style={{
                        padding: "12px 16px",
                        borderBottom: idx < pillarCategories.length - 1 ? `1px solid ${t.border}` : "none",
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        fontSize: 13,
                        color: t.text,
                      }}
                    >
                      <span style={{ color: t.sub }}>•</span>
                      <span>{cat}</span>
                    </div>
                  ))
                ) : (
                  <div
                    style={{
                      padding: "12px 16px",
                      fontSize: 13,
                      color: t.sub,
                      fontStyle: "italic",
                    }}
                  >
                    Sin categorías
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Separador */}
        <div
          style={{
            borderTop: "1px dashed",
            borderColor: t.border,
            margin: "24px 0",
          }}
        />

        {/* Botón Añadir Categoría */}
        <button
          onClick={onAddCategory}
          style={{
            width: "100%",
            padding: "16px",
            borderRadius: 12,
            border: `1.5px dashed ${t.border}`,
            background: "transparent",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            transition: "all 0.2s",
          }}
          onMouseEnter={(e) => {
            e.target.style.background = t.card;
            e.target.style.borderColor = t.text;
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "transparent";
            e.target.style.borderColor = t.border;
          }}
        >
          <span style={{ fontSize: 18 }}>+</span>
          <span>Añadir categoría</span>
        </button>
      </div>

      {/* Gradiente de desvanecimiento flotante */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: 80,
          background: isDark
            ? "linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.5) 40%, rgba(0, 0, 0, 0.9) 100%)"
            : "linear-gradient(to bottom, transparent 0%, rgba(248, 247, 255, 0.4) 40%, rgba(248, 247, 255, 0.9) 100%)",
          pointerEvents: "none",
          zIndex: 20,
        }}
      />
    </div>
  );
}
