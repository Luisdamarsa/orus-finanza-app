import { useState, useEffect } from "react";
import { PILLARS } from "../constants";

/**
 * AddCategoryPage.jsx - REFORMULADA (Crear + Editar)
 *
 * Página para agregar o editar una categoría (mismo formato que Nueva Transacción)
 *
 * Características:
 * - Modo NUEVO: Input vacío, pilar sin seleccionar
 * - Modo EDITAR: Pre-llena nombre y pilar, botón guardar deshabilitado hasta cambio
 * - Botón guardar (✓) en esquina inferior derecha
 * - Botón eliminar (🗑️) en esquina inferior izquierda (solo en modo edición)
 * - Deduplicación automática con números crecientes
 *
 * Props:
 *   isDark - Tema oscuro
 *   onBack - Callback para volver atrás
 *   onSave - Callback(pillarId, categoryName) para guardar
 *   onDelete - Callback(categoryName, pillarId) para eliminar (solo edición)
 *   categories - {pillarId: [cat1, cat2, ...]} para validar duplicados
 *   isEditing - Boolean si está editando
 *   editingCategoryName - Nombre de la categoría a editar
 *   editingPillarId - Pilar actual de la categoría
 */
export default function AddCategoryPage({
  isDark,
  onBack,
  onSave,
  onDelete,
  categories = {},
  isEditing = false,
  editingCategoryName = null,
  editingPillarId = null,
}) {
  const [description, setDescription] = useState("");
  const [selectedPillar, setSelectedPillar] = useState(null);
  const [hasChanged, setHasChanged] = useState(false);

  // Pre-llenar datos en modo edición
  useEffect(() => {
    if (isEditing && editingCategoryName) {
      setDescription(editingCategoryName);
      setSelectedPillar(editingPillarId || null);
      setHasChanged(false);
    }
  }, [isEditing, editingCategoryName, editingPillarId]);

  const t = isDark
    ? { bg: "#000000", card: "#1E1E2E", border: "#2D2D3A", text: "#F0EEFF", sub: "#7B7A99" }
    : { bg: "#F8F7FF", card: "#FFFFFF", border: "#E5E3F5", text: "#1A1830", sub: "#9896B0" };

  // Validar si descripción tiene >= 2 caracteres
  const isValidLength = description.trim().length >= 2;

  // Detectar cambios (solo en modo edición)
  useEffect(() => {
    if (isEditing) {
      const descriptionChanged = description.trim() !== editingCategoryName?.trim();
      const pillarChanged = selectedPillar !== editingPillarId;
      setHasChanged(descriptionChanged || pillarChanged);
    }
  }, [description, selectedPillar, isEditing, editingCategoryName, editingPillarId]);

  // En modo nuevo: necesita 2+ caracteres
  // En modo edición: necesita cambio + 2+ caracteres
  const canSave = isValidLength && (isEditing ? hasChanged : true);

  /**
   * Obtiene el nombre final con número de deduplicación si existe duplicado
   * @param {string} name - Nombre a verificar
   * @returns {string} Nombre con número agregado si existe duplicado
   */
  const getDeduplicatedName = (name) => {
    const trimmedName = name.trim();

    // Recolectar todos los nombres de categorías en ALL pilares
    const allCategoryNames = new Set();
    Object.values(categories).forEach(catList => {
      if (Array.isArray(catList)) {
        catList.forEach(cat => allCategoryNames.add(cat));
      }
    });

    // En modo edición, excluir el nombre actual de la búsqueda de duplicados
    if (isEditing && editingCategoryName) {
      allCategoryNames.delete(editingCategoryName);
    }

    // Si no existe el nombre, retornar tal cual
    if (!allCategoryNames.has(trimmedName)) {
      return trimmedName;
    }

    // Si existe, buscar el siguiente número disponible
    let counter = 2;
    let newName = `${trimmedName} ${counter}`;

    while (allCategoryNames.has(newName)) {
      counter++;
      newName = `${trimmedName} ${counter}`;
    }

    return newName;
  };

  const handleSave = () => {
    if (!canSave) return;

    const finalName = isEditing ? description.trim() : getDeduplicatedName(description);
    const pillarToSave = selectedPillar || "varios";

    onSave(pillarToSave, finalName);
  };

  const handleDelete = () => {
    if (isEditing && editingCategoryName && onDelete) {
      if (window.confirm(`¿Eliminar categoría "${editingCategoryName}"?`)) {
        onDelete(editingCategoryName, editingPillarId);
      }
    }
  };

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 40,
        background: "#000000",
        display: "flex",
        flexDirection: "column",
        padding: "60px 22px 24px",
        boxSizing: "border-box"
      }}
    >
      <style>{`@keyframes popIn { from { transform:scale(0.92);opacity:0 } to { transform:scale(1);opacity:1 } }`}</style>

      {/* Botón Atrás */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 0 }}>
        <button
          onClick={onBack}
          style={{
            width: 30,
            height: 30,
            borderRadius: 9,
            border: "none",
            background: isDark ? "#1E1E2E" : "#EEE9FF",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer"
          }}
        >
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke={isDark ? "#C4C2E0" : "#6B7280"}
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
        <span style={{ fontSize: 12, color: t.sub, fontWeight: 500 }}>
          Atrás
        </span>
      </div>

      {/* Contenido del formulario - centrado en toda la pantalla */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "22px",
          right: "22px",
          transform: "translateY(-50%)",
          zIndex: 41
        }}
      >
        <div
          style={{
            background: t.card,
            border: `1px solid ${t.border}`,
            borderRadius: 20,
            padding: "18px 18px 16px",
            boxShadow: isDark
              ? "0 8px 32px rgba(0,0,0,0.4)"
              : "0 4px 20px rgba(100,80,200,0.08)"
          }}
        >
          {/* ===== SECCIÓN 1: Título + Descripción ===== */}

          {/* Título */}
          <div
            style={{
              fontSize: 10,
              fontWeight: 800,
              color: "#9B6DFF",
              letterSpacing: 1,
              marginBottom: 12
            }}
          >
            {isEditing ? "CATEGORÍA" : "NUEVA CATEGORÍA"}
          </div>

          {/* Input de Descripción */}
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe la categoría (Arriendo, Salidas, etc...)"
            style={{
              width: "100%",
              background: "none",
              border: "none",
              outline: "none",
              fontSize: 14,
              fontWeight: description ? 700 : 400,
              color: description ? t.text : "#7B7A99",
              fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
              marginBottom: 14,
              padding: 0,
              boxSizing: "border-box"
            }}
          />

          {/* Separador */}
          <div style={{ height: 1, background: t.border, marginBottom: 12 }} />

          {/* ===== SECCIÓN 2: Selector de Pilar ===== */}

          {/* Label Pilar */}
          <div
            style={{
              fontSize: 9,
              fontWeight: 800,
              color: t.sub,
              letterSpacing: 0.6,
              marginBottom: 8,
              textTransform: "uppercase",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between"
            }}
          >
            <span>Pilar</span>
            {!selectedPillar && (
              <span
                style={{
                  fontSize: 8,
                  fontWeight: 500,
                  fontStyle: "italic",
                  color: t.sub,
                  opacity: 0.7
                }}
              >
                Sin selección = Varios (defecto)
              </span>
            )}
          </div>

          {/* Botones de Pilar - 5 columnas */}
          <div
            style={{
              display: "flex",
              gap: 6,
              flexWrap: "wrap",
              marginBottom: 0
            }}
          >
            {PILLARS.map((pillar) => {
              const isSelected = selectedPillar === pillar.id;
              return (
                <button
                  key={pillar.id}
                  onClick={() => setSelectedPillar(isSelected ? null : pillar.id)}
                  style={{
                    flex: "1 1 auto",
                    minWidth: 60,
                    padding: "6px 8px",
                    borderRadius: 12,
                    border: "none",
                    cursor: "pointer",
                    background: isSelected
                      ? pillar.color + "22"
                      : isDark
                        ? "#252538"
                        : "#F0EFF8",
                    color: isSelected ? pillar.color : t.sub,
                    fontSize: 11,
                    fontWeight: isSelected ? 700 : 600,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: 3,
                    outline: isSelected
                      ? `1.5px solid ${pillar.color}66`
                      : "1.5px solid transparent",
                    transition: "all 0.18s"
                  }}
                >
                  <span style={{ fontSize: 16 }}>{pillar.icon}</span>
                  <span>{pillar.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Botón Eliminar (🗑️) - Esquina Inferior Izquierda (solo en edición) */}
      {isEditing && (
        <div style={{ position: "absolute", bottom: 24, left: 22 }}>
          <button
            onClick={handleDelete}
            style={{
              width: 52,
              height: 52,
              borderRadius: "50%",
              border: "none",
              background: "linear-gradient(135deg, #EF4444, #DC2626)",
              cursor: "pointer",
              boxShadow: "0 6px 24px rgba(239,68,68,0.45)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: 1,
              transition: "all 0.2s"
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.08)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)";
            }}
          >
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <polyline points="3 6 5 6 21 6" />
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
              <line x1="10" y1="11" x2="10" y2="17" />
              <line x1="14" y1="11" x2="14" y2="17" />
            </svg>
          </button>
        </div>
      )}

      {/* Botón Guardar (✓) - Esquina Inferior Derecha */}
      <div style={{ position: "absolute", bottom: 24, right: 22 }}>
        <button
          onClick={handleSave}
          disabled={!canSave}
          style={{
            width: 52,
            height: 52,
            borderRadius: "50%",
            border: "none",
            background: "linear-gradient(135deg, #9B6DFF, #4F8EF7)",
            cursor: canSave ? "pointer" : "not-allowed",
            boxShadow: "0 6px 24px rgba(155,109,255,0.45)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            opacity: canSave ? 1 : 0.45,
            transition: "opacity 0.2s"
          }}
        >
          <svg
            width="22"
            height="22"
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </button>
      </div>
    </div>
  );
}
