import { useState, useCallback, useEffect } from "react";
import { ALL_CATS } from "../constants";

/**
 * useBudgets.js - Hook independiente para gestionar presupuestos de categorías
 *
 * Maneja presupuestos de categorías en sessionStorage durante la sesión.
 * Al recargar la app, se reinician desde ALL_CATS (sessionStorage se borra).
 * Al navegar entre pantallas, se mantienen en sessionStorage.
 *
 * Retorna:
 *   - categoryBudgets: {nombreCategoria: presupuesto, ...}
 *   - handleCategoryBudgetChange: (categoryName, value) → actualiza presupuesto
 */

export function useBudgets() {
  // 🔄 Estado de presupuestos de categorías (se carga desde sessionStorage)
  const [categoryBudgets, setCategoryBudgets] = useState(() => {
    try {
      const stored = sessionStorage.getItem("orus_category_budgets");
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error("Error loading category budgets:", e);
    }

    // Si no hay sessionStorage, iniciar desde ALL_CATS
    const budgets = {};
    ALL_CATS.forEach(cat => {
      budgets[cat.name] = cat.budget;
    });
    return budgets;
  });

  // 🔄 Guardar en sessionStorage cuando cambien (persiste en navegación, se borra al recargar)
  useEffect(() => {
    sessionStorage.setItem("orus_category_budgets", JSON.stringify(categoryBudgets));
  }, [categoryBudgets]);

  // Cambiar presupuesto de categoría
  const handleCategoryBudgetChange = useCallback((categoryName, value) => {
    const numValue = parseInt(value.replace(/\D/g, "")) || 0;
    setCategoryBudgets(prev => ({
      ...prev,
      [categoryName]: numValue
    }));
  }, []);

  // Agregar nuevas categorías al presupuesto
  const addCategoryBudget = useCallback((categoryName) => {
    setCategoryBudgets(prev => ({
      ...prev,
      [categoryName]: 0 // Nueva categoría comienza con presupuesto 0
    }));
  }, []);

  // Actualizar presupuestos cuando cambien las categorías
  // 🆕 Ahora limpia categorías que ya no existen y agrega nuevas
  const updateWithNewCategories = useCallback((categoriesMap) => {
    setCategoryBudgets(prev => {
      // 1. Recolectar todas las categorías que EXISTEN actualmente
      const existingCategories = new Set();

      // Agregar categorías de ALL_CATS
      ALL_CATS.forEach(cat => {
        existingCategories.add(cat.name);
      });

      // Agregar categorías del hook useCategories
      Object.values(categoriesMap).forEach(categoryList => {
        categoryList.forEach(catName => {
          existingCategories.add(catName);
        });
      });

      // 2. Crear presupuestos limpios (solo categorías que existen)
      const updated = {};

      // Agregar categorías de ALL_CATS con sus valores dummy
      ALL_CATS.forEach(cat => {
        updated[cat.name] = prev[cat.name] || cat.budget;
      });

      // Agregar categorías nuevas del hook (iniciando en 0)
      existingCategories.forEach(catName => {
        if (!updated.hasOwnProperty(catName)) {
          updated[catName] = prev[catName] || 0;
        }
      });

      // 3. ✅ Eliminar categorías que ya no existen
      const filtered = {};
      Object.keys(updated).forEach(catName => {
        if (existingCategories.has(catName)) {
          filtered[catName] = updated[catName];
        }
      });

      return filtered;
    });
  }, []);

  return {
    categoryBudgets,
    handleCategoryBudgetChange,
    addCategoryBudget,
    updateWithNewCategories,
    setCategoryBudgets
  };
}
