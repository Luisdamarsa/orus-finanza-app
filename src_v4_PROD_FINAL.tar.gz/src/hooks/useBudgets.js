import { useState, useCallback } from "react";
import { ALL_CATS } from "../constants";

/**
 * useBudgets.js - Hook independiente para gestionar presupuestos de categorías
 *
 * Maneja presupuestos de categorías en memoria durante la sesión.
 * Al recargar la app, se reinician desde ALL_CATS.
 *
 * Retorna:
 *   - categoryBudgets: {nombreCategoria: presupuesto, ...}
 *   - handleCategoryBudgetChange: (categoryName, value) → actualiza presupuesto
 */

export function useBudgets() {
  // Estado de presupuestos de categorías (se reinicia al montar)
  const [categoryBudgets, setCategoryBudgets] = useState(() => {
    const budgets = {};
    ALL_CATS.forEach(cat => {
      budgets[cat.name] = cat.budget;
    });
    return budgets;
  });

  // Cambiar presupuesto de categoría
  const handleCategoryBudgetChange = useCallback((categoryName, value) => {
    const numValue = parseInt(value.replace(/\D/g, "")) || 0;
    setCategoryBudgets(prev => ({
      ...prev,
      [categoryName]: numValue
    }));
  }, []);

  // Agregar nuevas categorías al presupuesto
  const addCategoryBudget = useCallback((categoryName) => {
    setCategoryBudgets(prev => ({
      ...prev,
      [categoryName]: 0 // Nueva categoría comienza con presupuesto 0
    }));
  }, []);

  // Agregar múltiples categorías (ej: cuando vienen del hook useCategories)
  const updateWithNewCategories = useCallback((categoriesMap) => {
    setCategoryBudgets(prev => {
      const updated = { ...prev };

      // Agregar categorías de ALL_CATS que no estén
      ALL_CATS.forEach(cat => {
        if (!updated.hasOwnProperty(cat.name)) {
          updated[cat.name] = cat.budget;
        }
      });

      // Agregar categorías nuevas del hook que no estén
      Object.values(categoriesMap).forEach(categoryList => {
        categoryList.forEach(catName => {
          if (!updated.hasOwnProperty(catName)) {
            updated[catName] = 0;
          }
        });
      });

      return updated;
    });
  }, []);

  return {
    categoryBudgets,
    handleCategoryBudgetChange,
    addCategoryBudget,
    updateWithNewCategories,
    setCategoryBudgets
  };
}
